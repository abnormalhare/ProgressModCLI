# ProgressModCLI

ProgressCLI95 but moddable. What else did you expect? Made by BurningInfern0, modding capability by CreateSource.

Current Version: **0.3.100**

    *New Modding Capabilities!*
    - Ability to enable "easy game" gamemode
    

## Installation

Built on Python 3.

Dependencies: ```rich```

1. Download the zip file and extract.
2. Open your terminal/command prompt inside the extracted contents.
3. Make sure the depenencies have been met.
4. Simply do ```python boot.py```
